export { default } from './SimpleLayout';
