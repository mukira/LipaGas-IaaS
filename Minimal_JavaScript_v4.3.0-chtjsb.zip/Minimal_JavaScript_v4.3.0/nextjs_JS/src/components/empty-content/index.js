export { default } from './EmptyContent';
